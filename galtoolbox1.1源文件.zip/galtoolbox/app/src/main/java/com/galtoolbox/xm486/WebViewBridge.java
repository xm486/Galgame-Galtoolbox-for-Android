package com.galtoolbox.xm486;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class WebViewBridge {
    private Activity activity;
    
    public WebViewBridge(Activity activity) {
        this.activity = activity;
    }
    
    @JavascriptInterface
    public void saveImage(String imageUrl) {
        // 在Android中打开图片链接
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(imageUrl));
        try {
            activity.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(activity, "无法打开图片，请复制链接到浏览器保存", Toast.LENGTH_SHORT).show();
        }
    }
}
