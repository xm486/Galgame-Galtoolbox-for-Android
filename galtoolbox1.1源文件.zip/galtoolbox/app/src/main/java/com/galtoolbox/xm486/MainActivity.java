package com.galtoolbox.xm486;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    
    private WebView myWebView;
    private WebViewPool webViewPool;
    private RelativeLayout titleBar;
    private TextView titleText;
    private ImageButton toolIcon;
    private ProgressBar progressBar;
    private String homeUrl = "file:///android_asset/index.html";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // 设置全屏显示
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
                           WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        setContentView(R.layout.activity_main);
        
        // 初始化标题栏组件
        titleBar = (RelativeLayout) findViewById(R.id.custom_title_bar);
        titleText = (TextView) findViewById(R.id.title_text);
        toolIcon = (ImageButton) findViewById(R.id.tool_icon);
        progressBar = (ProgressBar) findViewById(R.id.progress_bar);
        
        // 设置工具图标的点击事件
        toolIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToolMenu(v);
            }
        });
        
        // 初始化WebView池
        webViewPool = WebViewPool.getInstance();
        
        // 从池中获取WebView
        myWebView = webViewPool.acquireWebView(this);
        
        // 将WebView添加到布局容器
        FrameLayout webContainer = (FrameLayout) findViewById(R.id.web_container);
        webContainer.addView(myWebView);
        
        // 添加JavaScript接口，用于长按图片保存
myWebView.addJavascriptInterface(new WebViewBridge(this), "WebViewBridge");
        
        // 配置WebSettings
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        webSettings.setSupportZoom(true);
        
        // 启用缓存
        webSettings.setAppCacheEnabled(true);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        
        // 设置WebViewClient - 修复自定义协议问题
        myWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // 1. 处理自定义协议（如bilibili://）
                if (url.startsWith("http://") || url.startsWith("https://") || 
                    url.startsWith("file://") || url.startsWith("javascript:")) {
                    // 标准协议，在WebView内打开
                    view.loadUrl(url);
                    return true;
                } else {
                    // 自定义协议，尝试用外部应用打开
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        startActivity(intent);
                        return true; // 返回true表示已处理
                    } catch (Exception e) {
                        // 如果没有应用能处理此协议，显示提示
                        Toast.makeText(MainActivity.this, 
                                      "无法打开此链接，请确保已安装相应应用", 
                                      Toast.LENGTH_SHORT).show();
                        return true;
                    }
                }
            }
            
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // 更新标题
                String pageTitle = view.getTitle();
                if (pageTitle != null && pageTitle.length() > 0) {
                    titleText.setText(pageTitle);
                }
                // 隐藏进度条
                progressBar.setVisibility(View.GONE);
                
                // 注入JavaScript，实现长按图片保存功能
                injectImageSaveScript();
            }
            
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                // 显示进度条
                progressBar.setVisibility(View.VISIBLE);
                progressBar.setProgress(10);
            }
        });
        
        // 设置WebChromeClient
        myWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                // 更新进度条
                if (newProgress < 100) {
                    progressBar.setProgress(newProgress);
                } else {
                    progressBar.setProgress(100);
                    // 进度完成后隐藏进度条
                    progressBar.setVisibility(View.GONE);
                }
            }
            
            @Override
            public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view, title);
                // 更新标题
                if (title != null && title.length() > 0) {
                    titleText.setText(title);
                }
            }
        });
        
        // 设置下载监听器
        myWebView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, 
                                      String contentDisposition, String mimetype, 
                                      long contentLength) {
                // 尝试用浏览器打开
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, 
                                  "无法打开链接，请复制链接到浏览器打开", 
                                  Toast.LENGTH_LONG).show();
                }
            }
        });
        
        // 加载初始URL
        myWebView.loadUrl(homeUrl);
    }
    
    // 注入JavaScript，实现长按图片保存功能
    private void injectImageSaveScript() {
        String javascript = "javascript:(function() {" +
            "var images = document.getElementsByTagName('img');" +
            "for(var i = 0; i < images.length; i++) {" +
            "  var img = images[i];" +
            "  img.oncontextmenu = function(e) {" +
            "    e.preventDefault();" +
            "    window.WebViewBridge.saveImage(this.src);" +
            "    return false;" +
            "  };" +
            "}" +
            "})()";
        
        myWebView.loadUrl(javascript);
    }
    
    // 显示工具菜单
    private void showToolMenu(View anchorView) {
        PopupMenu popupMenu = new PopupMenu(this, anchorView);
        popupMenu.getMenuInflater().inflate(R.menu.tool_menu, popupMenu.getMenu());
        
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.menu_copy_url) {
                    // 复制当前URL
                    String currentUrl = myWebView.getUrl();
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (clipboard != null) {
                        ClipData clip = ClipData.newPlainText("WebView URL", currentUrl);
                        clipboard.setPrimaryClip(clip);
                        Toast.makeText(MainActivity.this, "链接已复制", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                } else if (itemId == R.id.menu_refresh) {
                    // 刷新页面
                    myWebView.reload();
                    return true;
                } else if (itemId == R.id.menu_go_back) {
                    // 返回上一页
                    if (myWebView.canGoBack()) {
                        myWebView.goBack();
                    }
                    return true;
                } else if (itemId == R.id.menu_go_forward) {
                    // 前进下一页
                    if (myWebView.canGoForward()) {
                        myWebView.goForward();
                    }
                    return true;
                } else if (itemId == R.id.menu_home) {
                    // 返回主页
                    myWebView.loadUrl(homeUrl);
                    return true;
                } else if (itemId == R.id.menu_save_page) {
                    // 保存当前页面
                    saveCurrentPage();
                    return true;
                }
                return false;
            }
        });
        
        popupMenu.show();
    }
    
    // 保存当前页面
    private void saveCurrentPage() {
        String currentUrl = myWebView.getUrl();
        if (currentUrl != null) {
            // 尝试用浏览器打开页面，用户可以选择保存页面
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl));
                startActivity(intent);
                Toast.makeText(this, "正在浏览器中打开页面，可在浏览器中保存", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "无法保存页面", Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    // 处理返回键
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (myWebView != null && myWebView.canGoBack()) {
                myWebView.goBack();
                return true;
            } else {
                finish();
            }
        }
        return super.onKeyDown(keyCode, event);
    }
    
    @Override
    protected void onDestroy() {
        if (myWebView != null) {
            // 从父容器中移除WebView
            ViewGroup parent = (ViewGroup) myWebView.getParent();
            if (parent != null) {
                parent.removeView(myWebView);
            }
            
            // 将WebView回池
            webViewPool.releaseWebView(myWebView);
            myWebView = null;
        }
        
        super.onDestroy();
    }
}
